import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.actor.Props;
import akka.actor.UntypedActor;
import akka.event.Logging;
import akka.event.LoggingAdapter;
import akka.pattern.Patterns;
import akka.util.Timeout;
import scala.concurrent.Await;
import scala.concurrent.Future;
import scala.concurrent.duration.Duration;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;


public class Main {
    public static void main(String[] args) throws Exception {
        Timeout timeout = new Timeout(Duration.create(5, "seconds"));
        System.out.println("Hello Actor's World!\n");
        ActorSystem system = ActorSystem.create("Shower");
        ActorRef checkpoint = system.actorOf(Props.create(Checkpoint.class), "Checkpoint");
        Future<Object> future1 = Patterns.ask(checkpoint,
                new Checkpoint.WantShower(Checkpoint.Gender.MAN,1), 1000);
        Await.result(future1, timeout.duration());
        Future<Object> future2 = Patterns.ask(checkpoint,
                new Checkpoint.WantShower(Checkpoint.Gender.MAN,2), 1000);
        Future<Object> future3 = Patterns.ask(checkpoint,
                new Checkpoint.WantShower(Checkpoint.Gender.WOMAN,3), 1000);
        Future<Object> future4 = Patterns.ask(checkpoint,
                new Checkpoint.WantShower(Checkpoint.Gender.MAN,4), 1000);
        Future<Object> future5 = Patterns.ask(checkpoint,
                new Checkpoint.WantShower(Checkpoint.Gender.WOMAN,5), 1000);
        Future<Object> future6 = Patterns.ask(checkpoint,
                new Checkpoint.WantShower(Checkpoint.Gender.WOMAN,6), 1000);
    }
}
